#Azure CLI AKS Preview Extension#
This is an extension for AKS features. This will replace the full AKS module.

## How to use ##
Install this extension using the below CLI command
```
az extension add --name aks-preview
```

## Included Features
### Cluster Auto Scaler:
[more info](https://docs.microsoft.com/azure/aks/autoscaler)


#### create aks cluster with enabled cluster autoscaler
*Examples:*
```
az aks create \
    -g MyResourceGroup \
    -n MyManagedCluster \
    --enable-cluster-autoscaler \
    --min-count 1 \
    --max-count 5 \
    --node-count 3 \
    --kubernetes-version 1.11.3
```

#### enable cluster autoscaler for existing cluster
Note: make sure following setting:
1. min-count <= node-count
2. max-count >= node-count
3. kubernetes-version >= 1.10.6
*Examples:*
```
az aks update \
    -g MyResourceGroup \
    -n MyManagedCluster \
    --enable-cluster-autoscaler \
    --min-count 1 \
    --max-count 5
```

#### disable cluster autoscaler for exisiting enabled cluster
*Examples:*
```
az aks update \
    -g MyResourceGroup \
    -n MyManagedCluster \
    --disable-cluster-autoscaler
```

#### update min-count/max-count for exisiting enabled cluster
*Examples:*
```
az aks update \
    -g MyResourceGroup \
    -n MyManagedCluster \
    --update-cluster-autoscaler \
    --min-count 1 \
    --max-count 5
```

#### Enable apiserver authorized IP ranges

*Examples:*

```
az aks update \
    -g MyResourceGroup \
    -n MyManagedCluster \
    --api-server-authorized-ip-ranges "172.0.0.10/16,168.10.0.10/18"
```

#### Disable apiserver authorized IP ranges

*Examples:*

```
az aks update \
    -g MyResourceGroup \
    -n MyManagedCluster \
    --api-server-authorized-ip-ranges ""
```

#### Use VMAS for new cluster
*Examples:*
```
az aks create \
    -g MyResourceGroup \
    -n MyManagedCluster \
    --vm-set-type AvailabilitySet \
```

#### Use VMSS for new cluster
*Examples:*
```
az aks create \
    -g MyResourceGroup \
    -n MyManagedCluster \
    --vm-set-type VirtualMachineScaleSets \
```

#### Use VMSS for new cluster with availability zone feature
*Examples:*
```
az aks create \
    -g MyResourceGroup \
    -n MyManagedCluster \
    --vm-set-type VirtualMachineScaleSets \
    --zones 1 2 3
```

#### Enable pod security policy for new cluster
*Examples:*
```
az aks create \
    -g MyResourceGroup \
    -n MyManagedCluster \
    --enable-pod-security-policy \
```

#### Enable pod security policy for existing cluster
*Examples:*
```
az aks update \
    -g MyResourceGroup \
    -n MyManagedCluster \
    --enable-pod-security-policy \
```

#### Disable pod security policy for existing cluster
*Examples:*
```
az aks update \
    -g MyResourceGroup \
    -n MyManagedCluster \
    --disable-pod-security-policy \
```

#### Enable cluster auto scaler for a node pool
*Examples:*
```
az aks nodepool update \
    -g MyResourceGroup \
    -n nodepool1
    --cluster-name MyManagedCluster \
    --enable-cluster-autoscaler \
    --max-count 10 \
    --min-count 3
```

#### Update cluster auto scaler settings for a node pool
*Examples:*
```
az aks nodepool update \
    -g MyResourceGroup \
    -n nodepool1
    --cluster-name MyManagedCluster \
    --update-cluster-autoscaler \
    --max-count 10 \
    --min-count 3
```

#### Create aks cluster whose cluster resource group will be managed by a managed identity (instead of a service principal)
*Examples:*
```
az aks create \
    -g MyResourceGroup \
    -n MyManagedCluster \
    --enable-managed-identity
```

.. :changelog:

Release History
===============
0.4.25
+++++
* Update to use 2020-01-01 api-version
* Support cluster creation with server side encryption using customer managed key

0.4.24
+++++
* added custom header support

0.4.23
+++++
* Enable GA support of apiserver authorized IP ranges via paramater `--api-server-authorized-ip-ranges` in `az aks create` and `az aks update`

0.4.21
+++++
* Support cluster certificate rotation operation using `az aks rotate-certs`
* Add support for `az aks kanalyze`

0.4.20
+++++
* Add commands '--zones' and '-z' for availability zones in aks

0.4.19
+++++
* Refactor and remove a custom way of getting subscriptions

0.4.18
+++++
* Update to use 2019-10-01 api-version

0.4.17
+++++
* Add support for public IP per node during node pool creation
* Add support for taints during node pool creation
* Add support for low priority node pool

0.4.16
+++++
* Add support for `az aks kollect`
* Add support for `az aks upgrade --control-plane-only`

0.4.15
+++++
* Set default cluster creation to SLB and VMSS

0.4.14
+++++
* Add support for using managed identity to manage cluster resource group

0.4.13
++++++
* Rename a few options for ACR integration, which includes
  * Rename `--attach-acr <acr-name-or-resource-id>` in `az aks create` command, which allows for attach the ACR to AKS cluster.
  * Rename `--attach-acr <acr-name-or-resource-id>` and `--detach-acr <acr-name-or-resource-id>` in `az aks update` command, which allows to attach or detach the ACR from AKS cluster.
* Add "--enable-private-cluster" flag for enabling private cluster on creation.

0.4.12
+++++
* Bring back "enable-vmss" flag  for backward compatibility
* Revert "Set default availability type to VMSS" for backward compatibility
* Revert "Set default load balancer SKU to Standard" for backward compatibility

0.4.11
+++++
* Add support for load-balancer-profile
* Set default availability type to VMSS
* Set default load balancer SKU to Standard

0.4.10
+++++
* Add support for `az aks update --disable-acr --acr <name-or-id>`

0.4.9
+++++
* Use https if dashboard container port is using https

0.4.8
+++++
* Add update support for `--enable-acr` together with `--acr <name-or-id>`
* Merge `az aks create --acr-name` into `az aks create --acr <name-or-id>`

0.4.7
+++++
* Add support for `--enable-acr` and `--acr-name`

0.4.4
+++++
* Add support for per node pool auto scaler settings.
* Add `az aks nodepool update` to allow users to change auto scaler settings per node pool.
* Add support for Standard sku load balancer.

0.4.1
+++++
* Add `az aks get-versions -l location` to allow users to see all managed cluster versions.
* Add `az aks get-upgrades` to get all available versions to upgrade.
* Add '(preview)' suffix if kubernetes version is preview when using `get-versions` and `get-upgrades`

0.4.0
+++++
* Add support for Azure policy add-on.

0.3.2
+++++
* Add support of customizing node resource group

0.3.1
+++++
* Add support of pod security policy.

0.3.0
+++++
* Add support of feature `--node-zones`

0.2.3
+++++
* `az aks create/scale --nodepool-name` configures nodepool name, truncated to 12 characters, default - nodepool1
* Don't require --nodepool-name in "az aks scale" if there's only one nodepool

0.2.2
+++++
* Add support of Network Policy when creating new AKS clusters

0.2.1
+++++
* add support of apiserver authorized IP ranges

0.2.0
+++++
* Breaking Change: Set default agentType to VMAS
* opt-in VMSS by --enable-VMSS when creating AKS

0.1.0
+++++
* new feature `enable-cluster-autoscaler`
* default agentType is VMSS


